import csv

# ============================
# Funções de Manipulação de Arquivos
# ============================

def carregar_usuarios():
    usuarios = []
    try:
        with open("usuarios.csv", newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                usuarios.append(row)
    except FileNotFoundError:
        print("Arquivo de usuários não encontrado.")
    return usuarios

def salvar_usuarios(usuarios):
    with open("usuarios.csv", mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["nome", "senha", "cargo"])
        writer.writeheader()
        writer.writerows(usuarios)

def carregar_produtos():
    produtos = []
    try:
        with open("produtos.csv", newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                row["preco"] = float(row["preco"])
                row["quantidade"] = int(row["quantidade"])
                produtos.append(row)
    except FileNotFoundError:
        print("Arquivo de produtos não encontrado.")
    return produtos

def salvar_produtos(produtos):
    with open("produtos.csv", mode='w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["codigo", "nome", "preco", "quantidade"])
        writer.writeheader()
        writer.writerows(produtos)

# ============================
# Funções de Usuário
# ============================

def cadastrar_usuario(usuarios):
    nome = input("Nome: ")
    senha = input("Senha: ")
    cargo = input("Cargo: ")
    usuarios.append({"nome": nome, "senha": senha, "cargo": cargo})
    salvar_usuarios(usuarios)
    print("Usuário cadastrado.")

def listar_usuarios(usuarios):
    for u in usuarios:
        print(f"{u['nome']} - {u['cargo']}")

def atualizar_usuario(usuarios):
    nome = input("Nome do usuário a atualizar: ")
    for u in usuarios:
        if u['nome'] == nome:
            u['senha'] = input("Nova senha: ")
            u['cargo'] = input("Novo cargo: ")
            salvar_usuarios(usuarios)
            print("Usuário atualizado.")
            return
    print("Usuário não encontrado.")

def deletar_usuario(usuarios):
    nome = input("Nome do usuário a remover: ")
    for u in usuarios:
        if u['nome'] == nome:
            usuarios.remove(u)
            salvar_usuarios(usuarios)
            print("Usuário removido.")
            return
    print("Usuário não encontrado.")

# ============================
# Funções de Produto
# ============================

def cadastrar_produto(produtos):
    codigo = input("Código: ")
    nome = input("Nome: ")
    preco = float(input("Preço: "))
    quantidade = int(input("Quantidade: "))
    produtos.append({"codigo": codigo, "nome": nome, "preco": preco, "quantidade": quantidade})
    salvar_produtos(produtos)
    print("Produto cadastrado.")

def listar_produtos(produtos):
    for p in produtos:
        print(f"{p['codigo']} - {p['nome']} - R${p['preco']} - Qtde: {p['quantidade']}")

def buscar_produto(produtos):
    termo = input("Buscar por nome ou código: ").lower()
    for p in produtos:
        if termo in p['nome'].lower() or termo == p['codigo']:
            print(f"{p['codigo']} - {p['nome']} - R${p['preco']} - Qtde: {p['quantidade']}")
            return
    print("Produto não encontrado.")

def atualizar_produto(produtos):
    codigo = input("Código do produto a atualizar: ")
    for p in produtos:
        if p['codigo'] == codigo:
            p['nome'] = input("Novo nome: ")
            p['preco'] = float(input("Novo preço: "))
            p['quantidade'] = int(input("Nova quantidade: "))
            salvar_produtos(produtos)
            print("Produto atualizado.")
            return
    print("Produto não encontrado.")

def deletar_produto(produtos):
    codigo = input("Código do produto a remover: ")
    for p in produtos:
        if p['codigo'] == codigo:
            produtos.remove(p)
            salvar_produtos(produtos)
            print("Produto removido.")
            return
    print("Produto não encontrado.")

def ordenar_produtos_por_nome(produtos):
    for p in sorted(produtos, key=lambda x: x['nome'].lower()):
        print(f"{p['codigo']} - {p['nome']} - R${p['preco']} - Qtde: {p['quantidade']}")

def ordenar_produtos_por_preco(produtos):
    for p in sorted(produtos, key=lambda x: x['preco']):
        print(f"{p['codigo']} - {p['nome']} - R${p['preco']} - Qtde: {p['quantidade']}")

# ============================
# Menus
# ============================

def menu_gerente(usuarios, produtos):
    while True:
        print("
Menu do GERENTE")
        print("1 - Cadastrar usuário")
        print("2 - Listar usuários")
        print("3 - Atualizar usuário")
        print("4 - Remover usuário")
        print("5 - Gerenciar produtos")
        print("0 - Sair")
        opcao = input("Opção: ")

        if opcao == "1":
            cadastrar_usuario(usuarios)
        elif opcao == "2":
            listar_usuarios(usuarios)
        elif opcao == "3":
            atualizar_usuario(usuarios)
        elif opcao == "4":
            deletar_usuario(usuarios)
        elif opcao == "5":
            menu_produtos(produtos)
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")

def menu_funcionario(produtos):
    menu_produtos(produtos)

def menu_produtos(produtos):
    while True:
        print("
Menu de Produtos")
        print("1 - Cadastrar produto")
        print("2 - Listar produtos")
        print("3 - Buscar produto")
        print("4 - Atualizar produto")
        print("5 - Remover produto")
        print("6 - Ordenar por nome")
        print("7 - Ordenar por preço")
        print("0 - Voltar")
        opcao = input("Opção: ")

        if opcao == "1":
            cadastrar_produto(produtos)
        elif opcao == "2":
            listar_produtos(produtos)
        elif opcao == "3":
            buscar_produto(produtos)
        elif opcao == "4":
            atualizar_produto(produtos)
        elif opcao == "5":
            deletar_produto(produtos)
        elif opcao == "6":
            ordenar_produtos_por_nome(produtos)
        elif opcao == "7":
            ordenar_produtos_por_preco(produtos)
        elif opcao == "0":
            break
        else:
            print("Opção inválida.")

# ============================
# Login
# ============================

def login(usuarios):
    nome = input("Nome: ")
    senha = input("Senha: ")
    for u in usuarios:
        if u['nome'] == nome and u['senha'] == senha:
            return u
    return None

# ============================
# Execução principal
# ============================

def main():
    usuarios = carregar_usuarios()
    produtos = carregar_produtos()

    print("=== Sistema Trabalho Prático ===")
    usuario = login(usuarios)
    if not usuario:
        print("Login falhou.")
        return

    if usuario['cargo'].lower() == 'gerente':
        menu_gerente(usuarios, produtos)
    elif usuario['cargo'].lower() == 'funcionario':
        menu_funcionario(produtos)
    else:
        print("Usuário sem permissões.")

if __name__ == "__main__":
    main()
